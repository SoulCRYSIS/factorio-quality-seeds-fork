return
{
  width = 238,
  height = 268,
  shift = util.by_pixel( -0.5, -7.5),
  line_length = 1,
}