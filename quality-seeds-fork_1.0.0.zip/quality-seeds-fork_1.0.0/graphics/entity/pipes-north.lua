return
{
  width = 70,
  height = 54,
  shift = util.by_pixel(-3,-13),
  line_length = 1,
}
