return
{
  width = 52,
  height = 34,
  shift = util.by_pixel( -32.0, -51.0),
  line_length = 1,
}
