return
{
  width = 117,
  height = 71,
  shift = util.by_pixel(-8,3),
  line_length = 1,
}
