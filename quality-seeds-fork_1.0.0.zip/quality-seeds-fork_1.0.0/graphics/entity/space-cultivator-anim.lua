return
{
  width = 334,
  height = 360,
  shift = util.by_pixel(1.65, -0.55),
  line_length = 8,
}
